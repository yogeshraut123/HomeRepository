package com.neosoft.main.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

import com.neosoft.main.Model.User;

public interface HomeService {

	public void saveUser(User u);

	public void deleteUser(Integer uid);

	public void updatedata(User u);

	public Object findUserByUname(String uname);

	List<User> getUserByUsingSortingField();

	

	

}
