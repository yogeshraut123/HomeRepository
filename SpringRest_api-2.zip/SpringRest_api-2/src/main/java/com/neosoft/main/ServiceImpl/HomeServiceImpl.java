package com.neosoft.main.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.neosoft.main.Model.User;
import com.neosoft.main.Repository.HomeRepository;
import com.neosoft.main.Service.HomeService;

@Service
public class HomeServiceImpl implements HomeService {
	@Autowired
	HomeRepository hr;

	@Override
	public void saveUser(User u) {
		hr.save(u);

	}

	@Override
	public void deleteUser(Integer uid) {
		hr.deleteById(uid);

	}

	@Override
	public void updatedata(User u) {
		hr.save(u);

	}

	@Override
	public Object findUserByUname(String uname) {

		return hr.findUserByUname(uname);
	}

	@Override
	public List<User> getUserByUsingSortingField() {
		List<User> list = hr.findAll(Sort.by(Sort.Direction.ASC, "dob"));
		return list;
	}



}
